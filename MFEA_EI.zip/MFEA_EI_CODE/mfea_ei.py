# algorithms/mfea_ei.py

import numpy as np
import random
import pandas as pd

class MFEA_EI:
    def __init__(self, tasks, pop_size=100, num_generations=1000, excel_filename="mfea_ei_results.xlsx"):
        if not tasks:
            raise ValueError("Tasks list can not be empty.")

        self.tasks = tasks
        self.num_tasks = len(tasks)
        self.pop_size = pop_size
        self.num_generations = num_generations
        self.excel_filename = excel_filename

        self.dim = max(task['dim'] for task in tasks)
        self.internal_bounds = (-10, 10)

        self.population = None
        self.costs = None
        self.skill_factors = None

    # --- Helper functions  ---
    def _map_to_bounds(self, x_internal, lb, ub):
        internal_lb, internal_ub = self.internal_bounds
        x = np.asarray(x_internal)
        return lb + (x - internal_lb) / (internal_ub - internal_lb) * (ub - lb)

    def _sbx_crossover(self, parent1, parent2, eta=15):
        child1, child2 = np.copy(parent1), np.copy(parent2)
        for i in range(len(parent1)):
            if random.random() <= 0.5:
                if abs(parent1[i] - parent2[i]) > 1e-14:
                    x1, x2 = min(parent1[i], parent2[i]), max(parent1[i], parent2[i])
                    beta1 = 1.0 + (2.0 * (x1 - self.internal_bounds[0]) / (x2 - x1))
                    alpha1 = 2.0 - pow(beta1, -(eta + 1.0))
                    rand = random.random()
                    betaq1 = pow((rand * alpha1), (1.0 / (eta + 1))) if rand <= 1.0 / alpha1 else pow(
                        (1.0 / (2.0 - rand * alpha1)), (1.0 / (eta + 1)))
                    c1 = 0.5 * ((x1 + x2) - betaq1 * (x2 - x1))
                    beta2 = 1.0 + (2.0 * (self.internal_bounds[1] - x2) / (x2 - x1))
                    alpha2 = 2.0 - pow(beta2, -(eta + 1.0))
                    betaq2 = pow((rand * alpha2), (1.0 / (eta + 1))) if rand <= 1.0 / alpha2 else pow(
                        (1.0 / (2.0 - rand * alpha2)), (1.0 / (eta + 1)))
                    c2 = 0.5 * ((x1 + x2) + betaq2 * (x2 - x1))
                    c1, c2 = np.clip(c1, self.internal_bounds[0], self.internal_bounds[1]), np.clip(c2,
                                                                                                    self.internal_bounds[
                                                                                                        0],
                                                                                                    self.internal_bounds[
                                                                                                        1])
                    if random.random() < 0.5:
                        child1[i], child2[i] = c2, c1
                    else:
                        child1[i], child2[i] = c1, c2
        return child1, child2

    def _gaussian_mutation(self, x, sigma=0.1):
        return np.clip(x + np.random.normal(0, sigma, size=len(x)), self.internal_bounds[0], self.internal_bounds[1])

    def _scalar_fitness_and_skill_factor(self, costs):
        ranks = np.zeros_like(costs)
        for t in range(self.num_tasks):
            # When the cost is 'infinite', set the rank very high.
            temp_costs = np.copy(costs[:, t])
            inf_mask = np.isinf(temp_costs)
            if np.all(inf_mask):  # If all are infinite.
                ranks[:, t] = len(temp_costs)
            else:
                max_val = np.max(temp_costs[~inf_mask]) if np.any(~inf_mask) else 1
                temp_costs[inf_mask] = max_val + 1
                ranks[:, t] = np.argsort(np.argsort(temp_costs)) + 1

        min_ranks = np.min(ranks, axis=1)
        skill_factors = np.argmin(costs, axis=1)
        return 1.0 / min_ranks, skill_factors

    def run(self):
        """ Main logic of Charged-MFEA ."""

        # Initial evaluation
        self.population = np.random.uniform(self.internal_bounds[0], self.internal_bounds[1],
                                            size=(self.pop_size, self.dim))
        self.costs = np.zeros((self.pop_size, self.num_tasks))
        for i in range(self.pop_size):
            for t, task in enumerate(self.tasks):
                x_mapped = self._map_to_bounds(self.population[i, :task['dim']], task["lower_bound"],
                                               task["upper_bound"])
                self.costs[i, t] = task["function"](x_mapped)

        _, self.skill_factors = self._scalar_fitness_and_skill_factor(self.costs)
        results_data = []

        for gen in range(1, self.num_generations + 1):
            # --- Charges Calculation ---
            charges = np.zeros(self.pop_size)
            for t in range(self.num_tasks):
                task_idx = np.where(self.skill_factors == t)[0]
                if len(task_idx) > 0:
                    median_val = np.median(self.costs[task_idx, t])
                    for idx in task_idx:
                        if self.costs[idx, t] < median_val - 1e-9:
                            charges[idx] = -1.0
                        elif self.costs[idx, t] > median_val + 1e-9:
                            charges[idx] = 1.0
                        else:
                            charges[idx] = 0.0

            # --- Offspring Generation ---
            offspring = []
            while len(offspring) < self.pop_size:
                p1_idx, p2_idx = random.sample(range(self.pop_size), 2)
                sf1, sf2 = self.skill_factors[p1_idx], self.skill_factors[p2_idx]
                p1, p2 = self.population[p1_idx], self.population[p2_idx]

                if sf1 == sf2:
                    o1, o2 = self._sbx_crossover(p1, p2)
                    o1, o2 = self._gaussian_mutation(o1), self._gaussian_mutation(o2)
                    offspring.extend([o1, o2])
                else:
                    if charges[p1_idx] * charges[p2_idx] < 0:
                        o1, o2 = self._sbx_crossover(p1, p2)
                        offspring.extend([o1, o2])
                    elif charges[p1_idx] > 0 and charges[p2_idx] > 0:
                        best1 = self.population[np.argmin(self.costs[:, sf1])]
                        best2 = self.population[np.argmin(self.costs[:, sf2])]
                        o1, _ = self._sbx_crossover(p1, best1)
                        o2, _ = self._sbx_crossover(p2, best2)
                        offspring.extend([o1, o2])
                    else:
                        offspring.extend([p1.copy(), p2.copy()])

            offspring = np.array(offspring[:self.pop_size])

            # ===========================================================================
            # ===========================================================================
            offspring_costs = np.zeros((self.pop_size, self.num_tasks))
            for i in range(self.pop_size):
                for t, task in enumerate(self.tasks):  # <--  Evaluate on every task -->
                    x_mapped = self._map_to_bounds(offspring[i, :task['dim']], task["lower_bound"], task["upper_bound"])
                    offspring_costs[i, t] = task["function"](x_mapped)
            # ===========================================================================

            # Selection
            combined_pop = np.vstack((self.population, offspring))
            combined_costs = np.vstack((self.costs, offspring_costs))
            _, combined_sf = self._scalar_fitness_and_skill_factor(combined_costs)

            combined_fitness = 1.0 / (np.min(np.argsort(np.argsort(combined_costs, axis=0), axis=0) + 1, axis=1))
            idx_best = np.argsort(-combined_fitness)[:self.pop_size]

            self.population = combined_pop[idx_best]
            self.costs = combined_costs[idx_best]
            self.skill_factors = combined_sf[idx_best]

            # Data logging
            best_costs_this_gen = [np.min(self.costs[:, t]) for t in range(self.num_tasks)]
            current_gen_results = {'Generation': gen}
            for t in range(self.num_tasks):
                current_gen_results[f'Task {t + 1} Best Cost'] = best_costs_this_gen[t]
            results_data.append(current_gen_results)

            if (gen == 1 or gen % 100 == 0 or gen == self.num_generations):
                print(
                    f"  Gen {gen}/{self.num_generations} -> best: {['{:.4e}'.format(b) for b in best_costs_this_gen]}")

        df = pd.DataFrame(results_data)
        df.to_excel(self.excel_filename, index=False)
        print(f"\nMFEA_EI run is completed. Result '{self.excel_filename}' is saved .")
        return results_data