
# main.py
import os
import importlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime


# --- Helper Functions ---
def get_available_items(folder_path):
    if not os.path.isdir(folder_path): return []
    items = [f.replace('.py', '') for f in os.listdir(folder_path) if f.endswith('.py') and not f.startswith('__')]
    return sorted(items)


def sphere_function(x): return np.sum(x ** 2)


def plot_results(results_data, title):
    pass  # Plotting is disabled


# --- FE Data Generator Function ---
def generate_fe_data(iteration_df, pop_size, num_tasks, max_fes=100000, fe_interval=5000):
    iteration_df['Cumulative FEs'] = (iteration_df['Generation']) * pop_size
    fe_milestones = np.arange(fe_interval, max_fes + fe_interval, fe_interval)
    fe_results = []
    cost_columns = [col for col in iteration_df.columns if 'Cost' in col or 'Fitness' in col]
    for run in iteration_df['Run'].unique():
        run_data = iteration_df[iteration_df['Run'] == run]
        best_costs_at_milestone = {col: np.inf for col in cost_columns}
        for fe_milestone in fe_milestones:
            relevant_data = run_data[run_data['Cumulative FEs'] <= fe_milestone]
            if not relevant_data.empty:
                for col in cost_columns:
                    best_costs_at_milestone[col] = min(best_costs_at_milestone[col], relevant_data[col].min())
            record = {'Run': run, 'FEs': fe_milestone}
            record.update(best_costs_at_milestone)
            fe_results.append(record)
    return pd.DataFrame(fe_results)


# --- Main Program ---
if __name__ == '__main__':
    available_algorithms = get_available_items('algorithms')
    if not available_algorithms:
        print("Error: 'The 'algorithms' folder was not found or it is empty.")
    else:
        print("Hello! Please choose which algorithm to run:")
        for i, algo_name in enumerate(available_algorithms):
            print(f"  {i + 1}: {algo_name.upper()}")
        try:
            algo_choice = int(input("Choose Algorithm Number: "))
            selected_algo_name = available_algorithms[algo_choice - 1]
            print(f"\nyou '{selected_algo_name.upper()}' choose.")

            benchmark_options = {
                                # CEC 2017 Problems
                                2: {'name': 'CEC17_MTSO_P1',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(1)},
                                3: {'name': 'CEC17_MTSO_P2',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(2)},
                                4: {'name': 'CEC17_MTSO_P3',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(3)},
                                5: {'name': 'CEC17_MTSO_P4',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(4)},
                                6: {'name': 'CEC17_MTSO_P5',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(5)},
                                7: {'name': 'CEC17_MTSO_P6',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(6)},
                                8: {'name': 'CEC17_MTSO_P7',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(7)},
                                9: {'name': 'CEC17_MTSO_P8',
                                    'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(8)},
                                10: {'name': 'CEC17_MTSO_P9',
                                     'loader': lambda: importlib.import_module('benchmarks.cec2017_mtso').get_problem(9)},
                                # WCCI 2020 MTSO Problems
                                11: {'name': 'WCCI20_MTSO_P1',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(1)},
                                12: {'name': 'WCCI20_MTSO_P2',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(2)},
                                13: {'name': 'WCCI20_MTSO_P3',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(3)},
                                14: {'name': 'WCCI20_MTSO_P4',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(4)},
                                15: {'name': 'WCCI20_MTSO_P5',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(5)},
                                16: {'name': 'WCCI20_MTSO_P6',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(6)},
                                17: {'name': 'WCCI20_MTSO_P7',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(7)},
                                18: {'name': 'WCCI20_MTSO_P8',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(8)},
                                19: {'name': 'WCCI20_MTSO_P9',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(9)},
                                20: {'name': 'WCCI20_MTSO_P10',
                                     'loader': lambda: importlib.import_module('benchmarks.wcci2020_mtso').get_problem(10)},

                            }

            # General settings for all runs
            num_runs = int(input("\nHow many times do you want to run each experiment? (e.g., 10, 30): "))
            if num_runs < 1: num_runs = 1
            pop_size_input = input(f"What should be the population size for all benchmarks? (default is 100): ")
            POP_SIZE = int(pop_size_input) if pop_size_input.strip() else 100
            generations_input = input(f"How many generations should be used for all benchmarks? (default is 1000): ")
            GENERATIONS = int(generations_input) if generations_input.strip() else 1000

            # Dynamic module loading
            algo_module = importlib.import_module(f'algorithms.{selected_algo_name}')
            os.makedirs('results', exist_ok=True)

            # =========================  1: Class ka naam theek karna =========================
            class_name = selected_algo_name.upper().replace('_', '')
            if selected_algo_name == 'mfea_ii':
                class_name = 'MFEA_II'
            if selected_algo_name == 'mfea_ei':
                class_name = 'MFEA_EI'
            # =====================================================================================

            AlgorithmClass = getattr(algo_module, class_name)
            all_benchmarks_data = {}

            total_benchmarks = len(benchmark_options)
            for idx, (bench_key, bench_info) in enumerate(benchmark_options.items()):
                selected_benchmark_name = bench_info['name']
                print("\n" + "=" * 70)
                print(
                    f"BENCHMARK {idx + 1}/{total_benchmarks}: '{selected_benchmark_name}' run ...")
                print("=" * 70 + "\n")

                tasks = bench_info['loader']()
                all_run_final_bests = []
                all_iteration_data = []

                for i in range(1, num_runs + 1):
                    print(f"--- RUN {i}/{num_runs} for {selected_benchmark_name} ---")

                    # ===================  2: Create a separate file for MFEA_EI ====================
                    # If MFEA_EI is selected, a separate file will be created for each run
                    if selected_algo_name == 'mfea_ei':
                        excel_filename = f"results/MFEA_EI_Dynamics_{selected_benchmark_name}_Run_{i}.xlsx"
                        solver = AlgorithmClass(tasks=tasks, pop_size=POP_SIZE, num_generations=GENERATIONS,
                                                excel_filename=excel_filename)
                    elif selected_algo_name == 'ga':
                        solver = AlgorithmClass(problem=tasks[1], pop_size=POP_SIZE, num_generations=GENERATIONS)
                    else:
                        solver = AlgorithmClass(tasks=tasks, pop_size=POP_SIZE, num_generations=GENERATIONS)
                    # ===================================================================================

                    # ============== CHANGE 3: Separating the two outputs received from .run() ==============
                    # Now .run() can return two things, we are handling it here
                    solver_output = solver.run()
                    if isinstance(solver_output, tuple) and len(solver_output) == 2:
                        # In the case of MFEA_EI, two lists will be received
                        convergence_results, dynamics_results = solver_output
                    else:
                        # For the other algorithms, only a single list will be received
                        convergence_results = solver_output

                    if convergence_results:
                        run_df = pd.DataFrame(convergence_results)
                        # ====================================================================================
                        final_bests = run_df.iloc[-1].to_dict()
                        all_run_final_bests.append(final_bests)
                        run_df['Run'] = i
                        all_iteration_data.append(run_df)

                if all_iteration_data:
                    full_iteration_df = pd.concat(all_iteration_data, ignore_index=True)
                    final_bests_df = pd.DataFrame(all_run_final_bests)
                    cost_columns = [col for col in final_bests_df.columns if 'Cost' in col or 'Fitness' in col]
                    summary_df = final_bests_df[cost_columns].agg(['mean', 'std']).T
                    num_tasks = len(tasks)
                    fe_df = generate_fe_data(full_iteration_df, POP_SIZE, num_tasks)

                    all_benchmarks_data[selected_benchmark_name] = {
                        'summary': summary_df,
                        'iteration_data': full_iteration_df,
                        'fe_data': fe_df
                    }
                    print(f"'{selected_benchmark_name}' # The results have been successfully collected.")

            print("\n" + "=" * 20 + " ALL BENCHMARKS ARE COMPLETED  " + "=" * 20)

            if all_benchmarks_data:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                # Used replace('_', '') to remove underscores from the filename
                final_excel_filename = f"results/Analysis_{class_name.replace('_', '')}_All_Benchmarks_{timestamp}.xlsx"

                with pd.ExcelWriter(final_excel_filename, engine='openpyxl') as writer:
                    master_summary_list = []
                    for benchmark_name, data in all_benchmarks_data.items():
                        summary = data['summary'].copy()
                        summary['Benchmark'] = benchmark_name
                        master_summary_list.append(summary.reset_index().rename(columns={'index': 'Task'}))

                    master_summary_df = pd.concat(master_summary_list, ignore_index=True)
                    master_summary_df.to_excel(writer, sheet_name='Master_Summary_All_Benchmarks', index=False)
                    print("\nA Master Summary Sheet has been created.")

                    for benchmark_name, data in all_benchmarks_data.items():
                        safe_sheet_name = benchmark_name.replace('[', '').replace(']', '').replace(':', '')[:31]

                        data['summary'].to_excel(writer, sheet_name=f"{safe_sheet_name}_Summ")
                        data['iteration_data'].to_excel(writer, sheet_name=f"{safe_sheet_name}_IterData", index=False)
                        if not data['fe_data'].empty:
                            data['fe_data'].to_excel(writer, sheet_name=f"{safe_sheet_name}_FEData", index=False)

                print(
                    f"\nBig Success, All {len(all_benchmarks_data)} benchmarks results '{final_excel_filename}'  save.")
                print("\nPreview of Master Summary :")
                print(master_summary_df)

            else:
                print("\nNo data was generated. The file is not being saved.")

        except (ValueError, IndexError, KeyError) as e:
            print(f"\nWrong input or error! Please select the correct number. Error: {e}")
        except Exception as e:
            import traceback

            traceback.print_exc()
            print(f"\nAn unknown error occurred: {e}")
