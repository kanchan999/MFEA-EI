
# benchmarks/cec2017_mtso.py
import numpy as np
import os
import scipy.io as sio


# --- Basic Benchmark Functions ---
def sphere(x): return np.sum(x ** 2)


def rosenbrock(x): return np.sum(100 * (x[:-1] ** 2 - x[1:]) ** 2 + (x[:-1] - 1) ** 2)


def ackley(x):
    D = len(x)
    return -20 * np.exp(-0.2 * np.sqrt(np.sum(x ** 2) / D)) - np.exp(np.sum(np.cos(2 * np.pi * x)) / D) + 20 + np.e


def rastrigin(x): return np.sum(x ** 2 - 10 * np.cos(2 * np.pi * x) + 10)


def griewank(x):
    D = len(x)
    return np.sum(x ** 2) / 4000 - np.prod(np.cos(x / np.sqrt(np.arange(1, D + 1)))) + 1


def weierstrass(x):
    D = len(x)
    a, b, k_max = 0.5, 3, 20
    res = 0
    for i in range(D):
        res += np.sum([a ** k * np.cos(2 * np.pi * b ** k * (x[i] + 0.5)) for k in range(k_max + 1)])
    res -= D * np.sum([a ** k * np.cos(np.pi * b ** k) for k in range(k_max + 1)])
    return res


def schwefel(x): return 418.9829 * len(x) - np.sum(x * np.sin(np.sqrt(np.abs(x))))


# --- Main Function to Get Problems (Updated to use correct variable names) ---
def get_problem(problem_id):
    """
     This function is called by main.py.
     It loads data from .mat files and returns a list of tasks.
    """
    problem_map = {
        1: "CI_H", 2: "CI_M", 3: "CI_L",
        4: "PI_H", 5: "PI_M", 6: "PI_L",
        7: "NI_H", 8: "NI_M", 9: "NI_L"
    }

    if problem_id not in problem_map:
        raise ValueError(f"CEC 2017 MTSO Problem {problem_id} is not defined.")

    file_name = f"{problem_map[problem_id]}.mat"
    data_path = os.path.join(os.path.dirname(__file__), 'cec2017_mtso_data', file_name)

    try:
        mat_data = sio.loadmat(data_path)
    except FileNotFoundError:
        print(f"FATAL ERROR: Data file not found at {data_path}")
        return []


    D1 = 50
    D2 = 25 if problem_id == 6 else 50

    # Load the data with the correct variable names
    M1 = mat_data.get('Rotation_Task1', np.identity(D1))
    O1 = mat_data.get('GO_Task1', np.zeros(D1)).flatten()
    M2 = mat_data.get('Rotation_Task2', np.identity(D2))
    O2 = mat_data.get('GO_Task2', np.zeros(D2)).flatten()

    # Define the function and its parameters for each problem
    if problem_id == 1:  # CI_H: Griewank, Rastrigin
        tasks = [
            {'function': lambda x: griewank(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -100, 'upper_bound': 100},
            {'function': lambda x: rastrigin(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50}
        ]
    elif problem_id == 2:  # CI_M: Ackley, Rastrigin
        tasks = [
            {'function': lambda x: ackley(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: rastrigin(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50}
        ]
    elif problem_id == 3:  # CI_L: Ackley, Schwefel
        tasks = [
            {'function': lambda x: ackley(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: schwefel(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -500, 'upper_bound': 500}
        ]
    elif problem_id == 4:  # PI_H: Rastrigin, Sphere
        tasks = [
            {'function': lambda x: rastrigin(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: sphere(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -100, 'upper_bound': 100}
        ]
    elif problem_id == 5:  # PI_M: Ackley, Rosenbrock
        tasks = [
            {'function': lambda x: ackley(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: rosenbrock(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50}
        ]
    elif problem_id == 6:  # PI_L: Ackley, Weierstrass
        tasks = [
            {'function': lambda x: ackley(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: weierstrass(M2 @ (x[:D2] - O2)), 'dim': D1, 'lower_bound': -0.5, 'upper_bound': 0.5}
        ]
    elif problem_id == 7:  # NI_H: Rosenbrock, Rastrigin
        tasks = [
            {'function': lambda x: rosenbrock(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: rastrigin(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50}
        ]
    elif problem_id == 8:  # NI_M: Griewank, Weierstrass
        tasks = [
            {'function': lambda x: griewank(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -100, 'upper_bound': 100},
            {'function': lambda x: weierstrass(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -0.5, 'upper_bound': 0.5}
        ]
    elif problem_id == 9:  # NI_L: Rastrigin, Schwefel
        tasks = [
            {'function': lambda x: rastrigin(M1 @ (x - O1)), 'dim': D1, 'lower_bound': -50, 'upper_bound': 50},
            {'function': lambda x: schwefel(M2 @ (x - O2)), 'dim': D1, 'lower_bound': -500, 'upper_bound': 500}
        ]
    else:
        
        return []

    return tasks