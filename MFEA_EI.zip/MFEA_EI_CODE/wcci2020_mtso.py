# benchmarks/wcci2020_mtso.py
import numpy as np
import os
from opfunu.cec_based.cec2014 import *  # import all  CEC 2014 functions from opfunu 


# =============================================================================
#  Helper Functions, to Load Data Files
# =============================================================================
def get_wcci_data_path():
    """'Provides the path to the 'wcci2020_data' folder."""
    return os.path.join(os.path.dirname(__file__), 'wcci2020_data')


def load_wcci_matrix(matrix_id, dim):
    """Load Rotation matrix."""
    path = get_wcci_data_path()
    fname = os.path.join(path, f'matrix_{matrix_id}')
    try:
        data = np.loadtxt(fname)
    
        if data.shape[0] > dim:
            return data[:dim, :dim]
        return data
    except Exception as e:
        print(f"Warning: WCCI Matrix file '{fname}' not found. Using Identity matrix instead.")
        return np.identity(dim)


def load_wcci_bias(bias_id, dim):
    """Load Shift vector (bias)."""
    path = get_wcci_data_path()
    fname = os.path.join(path, f'bias_{bias_id}')
    try:
        data = np.loadtxt(fname)
        # Slice the bias according to the dimension.
        return data[:dim]
    except Exception as e:
        print(f"Warning: WCCI Bias file '{fname}' not found. Using a zero vector instead.")
        return np.zeros(dim)


# =============================================================================
# Mapping CEC 2014 Functions using Opfunu
# (with F-numbers as per your provided table)
# =============================================================================
# Each function must be initialized with a specific dimension.
# We will do this inside the 'get_problem' function.
# Here, we are only mapping the function classes.
FNC_MAP = {
    6: F62014,  # Weierstrass Function
    7: F72014,  # Griewank's Function
    17: F172014,  # Hybrid Function 1
    13: F132014,  # HappyCat Function
    15: F152014,  # Expanded Griewank's plus Rosenbrock's Function
    21: F212014,  # Hybrid Function 5
    22: F222014,  # Hybrid Function 6
    5: F52014,  # Ackley's Function
    11: F112014,  # Schwefel's Function
    16: F162014,  # Expanded Scaffer’s F6 Function
    20: F202014,  # Hybrid Function 4
}

# =============================================================================
# WCCI 2020 MTSO Problems definitions
# 
# =============================================================================
PROBLEM_MAP = {
    1: {'fnc': [6, 6], 'dim': 50},  # P1: Weierstrass, Weierstrass
    2: {'fnc': [7, 7], 'dim': 50},  # P2: Griewank, Griewank
    3: {'fnc': [17, 17], 'dim': 50},  # P3: Hybrid Function 1, Hybrid Function 1
    4: {'fnc': [13, 13], 'dim': 50},  # P4: HappyCat, HappyCat
    5: {'fnc': [15, 15], 'dim': 50},  # P5: Expanded Griewank's plus Rosenbrock, ...
    6: {'fnc': [21, 21], 'dim': 50},  # P6: Hybrid Function 5, Hybrid Function 5
    7: {'fnc': [22, 22], 'dim': 50},  # P7: Hybrid Function 6, Hybrid Function 6
    8: {'fnc': [5, 5], 'dim': 50},  # P8: Ackley, Ackley
    9: {'fnc': [11, 16], 'dim': 50},  # P9: Schwefel, Expanded Scaffer’s F6
    10: {'fnc': [20, 21], 'dim': 50},  # P10: Hybrid Function 4, Hybrid Function 5
}


# =============================================================================
# Main Function:  To Generate Problem Set  
# =============================================================================
def get_problem(problem_id):
    """
     Generates a WCCI 2020 MTSO problem set.
     This function uses shift vectors and rotation matrices.
    """
    if problem_id not in PROBLEM_MAP:
        raise ValueError(f"WCCI 2020 MTSO Problem {problem_id} is not defined.")

    prob_info = PROBLEM_MAP[problem_id]
    dim = prob_info['dim']
    fnc_nums = prob_info['fnc']

    # Load data (each problem should have separate data files)
    # Assume that matrix_id and bias_id correspond to problem_id
    # (This is a general assumption;  may need to modify it according to data files)
    O1 = load_wcci_bias(problem_id * 2 - 1, dim)
    O2 = load_wcci_bias(problem_id * 2, dim)
    M1 = load_wcci_matrix(problem_id * 2 - 1, dim)
    M2 = load_wcci_matrix(problem_id * 2, dim)

    # Initialize the correct function classes from opfunu
    # Each function must be initialized with its dimension (ndim)
    func1_class = FNC_MAP[fnc_nums[0]]
    func2_class = FNC_MAP[fnc_nums[1]]

    func1_instance = func1_class(ndim=dim)
    func2_instance = func2_class(ndim=dim)

    # Define task functions with shifts and rotations
    # Use the func.evaluate() method
    task1_func = lambda x: func1_instance.evaluate((x - O1) @ M1)
    task2_func = lambda x: func2_instance.evaluate((x - O2) @ M2)

    # Return Final tasks list  
    tasks = [
        {'function': task1_func, 'dim': dim, 'lower_bound': -100, 'upper_bound': 100},
        {'function': task2_func, 'dim': dim, 'lower_bound': -100, 'upper_bound': 100}
    ]
    return tasks